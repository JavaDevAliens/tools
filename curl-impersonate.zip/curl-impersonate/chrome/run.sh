
printf "1. CHENNAI
2. HYDERABAD
3. KOLKATA
4. MUMBAI
5. NEW DELHI
"
echo "enter :"
read con
if [ $con="1" ]
then
 postid=3f6bf614-b0db-ec11-a7b4-001dd80234f6
elif [ $con="2" ]
then
    postid=436bf614-b0db-ec11-a7b4-001dd80234f6
elif [ $con="3" ]
then
    postid=466bf614-b0db-ec11-a7b4-001dd80234f6
elif [ $con="4" ]
then
    postid=486bf614-b0db-ec11-a7b4-001dd80234f6
elif [ $con="5" ]
then
    postid=4a6bf614-b0db-ec11-a7b4-001dd80234f6
fi

echo $postid
repeat=true

primaryId=f2eed2a1-0735-ef11-a296-001dd80b41ff
applications=f2eed2a1-0735-ef11-a296-001dd80b41ff
echo 'Enter cookie:'
read coke

while $repeat
 do
jj=$(shuf -i 999999999999999999-9999999999999999999 -n 1)



dayw=$(curl_chrome110 -s -b cookie_j.txt -c cookie_j.txt 'https://www.usvisascheduling.com/en-US/custom-actions/?route=/api/v1/schedule-group/get-family-ofc-schedule-days&cacheString='$jj \
  -H 'accept: application/json, text/javascript, */*; q=0.01' \
  -H 'accept-language: en-US,en;q=0.9' \
  -H 'content-type: application/x-www-form-urlencoded; charset=UTF-8' \
  -H 'cookie: ai_user=bW7XPWHbxqUoKtw4KYB9ZC|2024-06-27T12:44:07.129Z; Dynamics365PortalAnalytics=K1B_uMKhbzrM60Ir7RO5uC0U2KbRacP7EM6tZpRaqi_J1F93o46GY2CCZ0_oJmhGvIZokrO4rMUu7OhsNLnQPaU01dwKbZDLUY21M7RCSds7QWQwo9d2SZiQGPK7dsAD4QicNaJe9VHZwr1lDb-rFA2; ASP.NET_SessionId=wm3bvgquba2y5bu0siwrklew; ARRAffinity=3bf8829b4314cc88291bac4130bb39f2498ea1af76e709ccc5192f2a63139759; ARRAffinitySameSite=3bf8829b4314cc88291bac4130bb39f2498ea1af76e709ccc5192f2a63139759; timezoneoffset=-330; isDSTSupport=false; isDSTObserved=false; ContextLanguageCode=en-US; timeZoneCode=190; __cf_bm=oBZbFkeVhYcVHg27H5Jz_EGsjatAgRWkLyu_NURGaJc-1719688800-1.0.1.1-w58G37eknqN5sHxpKc6CHlhngJpNLe8uld7WsAiajfGm814GXawpopHNMSIfhdJzCCI5GkuFUXHreo6Y3gj5eQ; .AspNet.ApplicationCookie=iKLZUeEw6q0dNarmx58XUsAt9-jzNNHt7LAdYtvEzHfeXHr7cg5BAPdZKU3eZZWLzUhOqe4fM7qUQHTVuru54tDGxIRRpWOFGjiFcoENjD603s1wn7Cm3bCYjNGboN4M86bpuX_807GrhdCdg3lMs32ZD8KTJUz8PNlUyVRIvlx69x20tkhj4ZsQ2us1VZPHTghjmiHpULDQseA6k68XJ9yY-zO6aQDwVspMFhtf1Be2BHLe1ng-Si_GSUlk0oQ1bNRQq1tKni7xxJejkv5PdiGGL8rwJS9lp2exlO7J16ljgRUSK0kqxXmbT2LOYfJyx4pmc-wPt1yxKxj0wMk4tw4hhXztQnwCAUO7X9IiNbF5o2wxN9oR5NsvifeKD4G2gkfqamob-LnHW5IIX68Ad4s9mypW23KNexDGPTIO2D4s0SuD8pXR1X8YKvrQA36R6bjKbuLplDT4L6UG4nOJbdGaav3bPUJnca2xL8qSZHyE9fxzEy_O_a-6X6_S404PP2Kcg-1MQsQ_y8AgxRbH0CA24VmLg7cD7V-9sTyI2Vk_6KTHgIKHuIyB3vgMFMfu74T1UVe8-dG-Wg1HRGMSJtwKcvxK57ifoRRma4uEOFUzdv5xuZNcT5HpxA-pw6p9AgpOZaXZYOEUrX3u-wELDl_fYx8xWfKieUq_vSpqlcOkClzc_pqXAut1xpFKPkBCsGysld8lwoMYn8sJO5NYZ1pPnEuQJjxou1fVqHOjldNvRtgPCjfol1gfK4z7_G8Pw2Nwj5nsX9TG-RFfi6JwQXw_iE3WQEOqv6m9r-kdPLjkdNgJ2xCcDj4dhJfvAVgqwOqMQ44AuKFQfCWmMwTFgT8CpkGhU3vA4ydthnzPqdfmC6PeIbWI2LGaEAxVvnNmCy574FyU_tJLKkG7cVh8uMiVU2-X3VloxijY1m9idzc28oJpfz5w8LyltuUt5yzxlVDU_eIQo1NFW7QOm8WgvmYxzeoJrZVmWzoywzuAfSaGoPdfrWH6pECnb9_QbUmb-J2DyI7wi4KbFcwdak7EZFnXo3aSMD6Nz4dhDRbXwEm7o2kN1MbUrSLrxokpFgnXmTQpRpauGXlkrsj0tfpAbn5MVl08wU4O32W2dmEcM5ZPL0LVc-DewFe-jVLMITrZvOUoVXsOR7iF4VA3CTJsA8g-1aiaDv3Nqi0qywsU6TT_oBE_0TNG7qu956ZZgjJWSn9QtjwIAHbMEk2oE-K4aCWZIAYjJONVVo51R_MpDdrpQz-RRkZRdyLn1SPbKBOPPu9qdbqHVJD8c15ypK62PiWgzSoCfwekm8oj8h9Dcw98nNy4RP8_AaXCTv0t12rOOLJKdFaapO8WMioZU73vH_Nzo7a4yT2dNaksU6L1U6GZm2H-yUhOH1F0_gDrcciJhxiG5fFdWaQ1ZrqaxmCOIxvrYZLcgceE9azrzvlD4WwLRR_jZ-XFbE15O5H3GNWpesYTn8HgbB7H7s-JvwtLbPUdXxqMFX1PtokSW-NqSvmfS5rAqrVSG9s67EScw_nETMrzMEVYRO55Wu9SGO4L84VQ-atUPElqJ62nnfvp_wVaUhloDMOpigNR_4via697OcK8xOaiQNjm-QpxKN9rIVyLBEPOrm8ZabVH6fdd0BDrFAI4aQ0q8O8HFZ7kRzc_k55h6hvKQl7dw2z18OYoR1QaEdOnGSS7IH7w9oInPHb0yb76uAlUcj2zwb97gMHtMx_42fDDYoo_2DPHHKZRoG70iRBgA9A34rhxXA_HoNZE6QH30pd22R7Dttrv8zJeq9BPGC2IbTXJSytU3Yf6ogasW1tpKeI7AJehGca0M97yZo_h5i0yXtcYOzVfcWkgPGR9DwVNo3KyZ4lKC3tFQtc6iKcQBWnw_xhG_4si29aFkbD2Zf0D940sCot5I9rXf0JhmkbLviqcGO_6yCBpSH1KEe6fgBo7Vec12ItMz1r__h29bXW2gNVmR_DA1AL9Tl1FLzBQ8yKBgVNv27UmFXJFMNaYCIWt0-ecpBMY6tQQnYWyDX6H-zaOWo1XVYoPZpm5oZwknNnDYuQ6Loj3S9IJsGUC_yu0InemR-y_dGuCXiS1s5qoGCZd1I4WSGDlv82yzPpvk8rjFLBjk0GgvUkpo4LZuWvQPGfDlNvBzleXoqNRnsLTUQfy5LHkxJoO1mg-p5eJ0AOk5MEM-MF43Z_lkpilEdLlg89D8onSIsNfBc4xNn2y_OjU-oFl_SwQSeHYgAPf9m-kwt0zGGDJlm_5a-lNuYKhPD0xyn5TGjNG_p3jS-U6TgifqKoDrOxFB2kLdk4ME-h-rbESAXaZ9Zdp00YectYRtNMB0Np5ZZeF8SHExu7dbeSkFlCyHoEdGfWCPgVMBVQxRMFDbs08YPu16f_R4Iq_02gMWRfQGw-WQWDp6d4-DP2XuX72OUrneUEZEQNnzNH35Obs23T2Tvg0XVsBAcR2Y581c72ScLiJrAYZbcTcuouJgZ9cl-ERFMBe6Hs9-f2J4g28TVsOMOpuiy2i1dNhgk8u-xklDQF5guPuX02zvO2o-iassslyZhxLy0CXhHPvQf7l5cteWhtB8vGdVqKBlUE4lGfPGMTO7AXJAUNQOwqW8ToNb7J0jdxG0K-Hlwb46h5ZOnRaviAQ2ZEvANnm4r9IPZyZ5kguYpeVE82IcAMfwrACTpXE1eY0EZjUg9Pxx4dytLrNFtLV7TTAuoBjJBKiOGAPVoCR2U97SmJpPrD3AesFSX1ww82IclMjOZa9pd_QPahUYAYUuq7-nPNU3bDHr6cpT_-HuG1Ij52HptKy9xQbHaPZDXGbpKPOQwXQ_cVUM2NpSgknrgf7yZr8lsoERcnQoVKiUfscnr8F7uRoNgzfYFq3kRXgXcmoLgF2xhiGeev-Kof8Git0Uty4CDTOhVpJiVJbAV8lBNW3l-twtveO17rnlsjx3Rf7dkh0ce_oUmcZm2-_ik-XUBfTIV6_2kwndfRS7Mq4YaObRdF8Hxu3SU4g3OBnGsLKr3fbWFaXgtVC1W3cAlKeDSz60gXIqQoeurT3383Hv4PVkWRDg4PhBts0z9h9U0kxa6m6XxkzTe-fD8HOej0-5xL-XtJPpfHuG2cgBU_0xVpvrrlZpvoQEsgZwZD3ikRydCDhfjVSgPfmHN1iSX4SeejC2bXDqJJIP-MYMTd2WHPB9MGvhX3PKNUhOm0Oj-fBOwba_jKKsrNPd9-B0LHCuJI73qK-nnqWRcqaxvy8K-cUQy3Rs-QgLH9DCQGjoGpDNYCJjrYTaO1XfoAxBiZlqlfWuvbhECHSH4HItIhBvQX0HJHHD5i918FXY6T4iIR2DSmTF8peOsEH3wFJLV_V74-aSVIQbF2s0KaVg7js6psL98E3-p7izuH7HSbOYKPyUqdhGy_YwGqti20wpsQriu4w_9mXfwcVsewOFhUlpmr7J2RKU6-lYIj1b9TDJZGKwkf_bg1LAaNlJ8xmp3cdvHA8NHaX3SOzyropppWsqGqC5gNqHBJB9LlQ4Jadrl_rbLhkt_PhTjsx7fPb33OvzkL8xFvl9RIdSudYBnUZM9TCXUpdx_vuT_Fu4iYszZYWU00zsfxFDoWu564VE-r5aOrJurOmixYtcFI1gUsYUV6g9oquG7KrJKwfo8ptmJ6HZgKhqQ7QJ45D6brJG77TLRFBW4hSomjLUXcqzGzX9UtDqKtiMXr8Xuy3M1c3fTzFXgRj7AWhJOjjV7ThfObdyRLjCii6Bn2vY4dbvK2eY5jSnyUuabcSrTyl; cf_clearance=9aCOxKGGIHM1BN1slrWoc3V30A8efNjSS27T5kNQufE-1719689523-1.0.1.1-FUMFiYndxD4LQB8T9uGotU_NdWnnxq9iY3.NS.nZbKMPUjKz1gNXoLgzo9WQdnEoqm62_tHjh.BVerIiiXm0tw; ai_session=jWHQ7nPdD8tS/1mjWHeSyd|1719685306410|1719689651527' \
  -H 'origin: https://www.usvisascheduling.com' \
  -H 'priority: u=1, i' \
  -H 'referer: https://www.usvisascheduling.com/en-US/ofc-schedule/?reschedule=true' \
  -H 'request-id: |'$jj \
  -H 'sec-ch-ua: "Not/A)Brand";v="8", "Chromium";v="126", "Google Chrome";v="126"' \
  -H 'sec-ch-ua-mobile: ?0' \
  -H 'sec-ch-ua-platform: "Linux"' \
  -H 'sec-fetch-dest: empty' \
  -H 'sec-fetch-mode: cors' \
  -H 'sec-fetch-site: same-origin' \
  -H 'traceparent: 00-'$jj \
  -H 'user-agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36' \
  -H 'x-requested-with: XMLHttpRequest' \
  --data-raw 'parameters={"primaryId":"'"$primaryId"'","applications":["'"$applications"'"],"scheduleDayId":"","scheduleEntryId":"","postId":"'"$postid"'","isReschedule":"true"}'|python3 -c"
import  json,sys;
import subprocess
from datetime import date, timedelta
result=json.load(sys.stdin)

#print(result['ScheduleDays']);
if(len(result['ScheduleDays'])>0):
    portalRange=[]
    for i in result['ScheduleDays']:
        #print(i['Date'][:-9])
        portalRange.append(i['Date'][:-9])

    #print('========================')
    def date_range_list(start_date, end_date):
        # Return generator for a list datetime.date objects (inclusive) between start_date and end_date (inclusive).
        curr_date = start_date
        while curr_date <= end_date:
            yield curr_date 
            curr_date += timedelta(days=1)

    start_date = date(year=2024, month=10, day=17)
    stop_date = date(year=2024, month=10, day=25)
    date_list = date_range_list(start_date, stop_date)
    userRange = []

    for date in date_list:
        userRange.append(str(date))
        #print(date)
    #print(result['ScheduleDays'][0]['Date'])
    dateshow=result['ScheduleDays'][0]['Date']
    
    common = [a for a in portalRange if a in userRange]

    if(len(common)>0):
       
        for i in result['ScheduleDays']:
            if((i['Date'][:-9])==common[0]):
               # print(i['ID']+';'+common[0])
                dateshow= common[0]+';'+i['ID']
                break
    print(dateshow)
   
    ")


echo AD: $dayw

arrIN=(${dayw//;/ })
#echo $arrIN


dayid=${arrIN[1]}
#echo dayid:$dayid
#echo available Date: ${arrIN[0]}
if [ "$dayid" != "" ];then

#echo $arrIN

#echo ${arrIN[1]}
 timeId=$(curl_chrome110 -s -b cookie_j.txt -c cookie_j.txt 'https://www.usvisascheduling.com/en-US/custom-actions/?route=/api/v1/schedule-group/get-family-ofc-schedule-entries&cacheString='$jj \
   -H 'accept: application/json, text/javascript, */*; q=0.01' \
  -H 'accept-language: en-US,en;q=0.9' \
  -H 'content-type: application/x-www-form-urlencoded; charset=UTF-8' \
  -H 'cookie: '$coke \
  -H 'origin: https://www.usvisascheduling.com' \
  -H 'priority: u=1, i' \
  -H 'referer: https://www.usvisascheduling.com/en-US/ofc-schedule/' \
  -H 'request-id: |'$jj \
  -H 'sec-ch-ua: "Not/A)Brand";v="8", "Chromium";v="126", "Google Chrome";v="126"' \
  -H 'sec-ch-ua-arch: "x86"' \
  -H 'sec-ch-ua-bitness: "64"' \
  -H 'sec-ch-ua-full-version: "126.0.6478.126"' \
  -H 'sec-ch-ua-full-version-list: "Not/A)Brand";v="8.0.0.0", "Chromium";v="126.0.6478.126", "Google Chrome";v="126.0.6478.126"' \
  -H 'sec-ch-ua-mobile: ?0' \
  -H 'sec-ch-ua-model: ""' \
  -H 'sec-ch-ua-platform: "Linux"' \
  -H 'sec-ch-ua-platform-version: "5.15.0"' \
  -H 'sec-fetch-dest: empty' \
  -H 'sec-fetch-mode: cors' \
  -H 'sec-fetch-site: same-origin' \
  -H 'traceparent: 00-'$jj \
  -H 'user-agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36' \
  -H 'x-requested-with: XMLHttpRequest' \
  --data-raw 'parameters={"primaryId":"'"$primaryId"'","applications":["'"$applications"'"],"scheduleDayId":"'"$dayid"'","scheduleEntryId":"","postId":"'"$postid"'"}'|python3 -c"
import  json,sys;
import subprocess
from datetime import date, timedelta
result1=json.load(sys.stdin)

print(result1['ScheduleEntries'][0]['ID']);"
 )
echo $timeId   
curl_chrome110 -s -b cookie_j.txt -c cookie_j.txt 'https://www.usvisascheduling.com/en-US/custom-actions/?route=/api/v1/schedule-group/schedule-ofc-appointments-for-family&cacheString='$jj \
   -H 'accept: application/json, text/javascript, */*; q=0.01' \
  -H 'accept-language: en-US,en;q=0.9' \
  -H 'content-type: application/x-www-form-urlencoded; charset=UTF-8' \
  -H 'cookie: '$coke \
  -H 'origin: https://www.usvisascheduling.com' \
  -H 'priority: u=1, i' \
  -H 'referer: https://www.usvisascheduling.com/en-US/ofc-schedule/' \
  -H 'request-id: |'$jj \
  -H 'sec-ch-ua: "Not/A)Brand";v="8", "Chromium";v="126", "Google Chrome";v="126"' \
  -H 'sec-ch-ua-arch: "x86"' \
  -H 'sec-ch-ua-bitness: "64"' \
  -H 'sec-ch-ua-full-version: "126.0.6478.126"' \
  -H 'sec-ch-ua-full-version-list: "Not/A)Brand";v="8.0.0.0", "Chromium";v="126.0.6478.126", "Google Chrome";v="126.0.6478.126"' \
  -H 'sec-ch-ua-mobile: ?0' \
  -H 'sec-ch-ua-model: ""' \
  -H 'sec-ch-ua-platform: "Linux"' \
  -H 'sec-ch-ua-platform-version: "5.15.0"' \
  -H 'sec-fetch-dest: empty' \
  -H 'sec-fetch-mode: cors' \
  -H 'sec-fetch-site: same-origin' \
  -H 'traceparent: 00-'$jj \
  -H 'user-agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36' \
  -H 'x-requested-with: XMLHttpRequest' \
  --data-raw 'parameters={"primaryId":"'"$primaryId"'","applications":["'"$applications"'"],"scheduleDayId":"'"$dayid"'","scheduleEntryId":"'"$timeId"'","postId":"'"$postid"'"}'|python3 -c"
import  json,sys;
import subprocess
from datetime import date, timedelta
result1=json.load(sys.stdin)

print('=============**booked*****************');"
 repeat=false


else
    echo 'At: '$(date +%H:%M:%S)
fi

 done
