while true
 do
jj=$(shuf -i 999999999999999999-9999999999999999999 -n 1)



dayw=$(curl_chrome110 -s -b cookie_j.txt -c cookie_j.txt 'https://www.usvisascheduling.com/en-US/custom-actions/?route=/api/v1/schedule-group/get-family-ofc-schedule-days&cacheString='$jj \
  -H 'accept: application/json, text/javascript, */*; q=0.01' \
  -H 'accept-language: en-US,en;q=0.9' \
  -H 'content-type: application/x-www-form-urlencoded; charset=UTF-8' \
  -H 'cookie: ai_user=bW7XPWHbxqUoKtw4KYB9ZC|2024-06-27T12:44:07.129Z; Dynamics365PortalAnalytics=K1B_uMKhbzrM60Ir7RO5uC0U2KbRacP7EM6tZpRaqi_J1F93o46GY2CCZ0_oJmhGvIZokrO4rMUu7OhsNLnQPaU01dwKbZDLUY21M7RCSds7QWQwo9d2SZiQGPK7dsAD4QicNaJe9VHZwr1lDb-rFA2; ASP.NET_SessionId=wm3bvgquba2y5bu0siwrklew; ARRAffinity=3bf8829b4314cc88291bac4130bb39f2498ea1af76e709ccc5192f2a63139759; ARRAffinitySameSite=3bf8829b4314cc88291bac4130bb39f2498ea1af76e709ccc5192f2a63139759; __cf_bm=Ix69pf34sKixviuSh0w64DBnpG5kegC5IaV02eN0jhw-1719654627-1.0.1.1-iBOQom.GlMXt0uzomg06CeL6bnOiTlZ3i99L3NaoOf5a6jyKdTv4eAzRp_7j3lRonFTtcdg_VUfCCBuSBPdTFg; timezoneoffset=-330; isDSTSupport=false; isDSTObserved=false; ContextLanguageCode=en-US; cf_clearance=ilz3r1TtxCiRZd5Zo_4ZgGJ6XP0e1bpF79E9MN.WUrc-1719654660-1.0.1.1-w.lIap.jnjrTyN0ErCrIxoM_MlHMt_PYMOu6VT5hG_16SZO0OJ8syXF7kIeWuAHWZJs6i2LLyfXNi4Ry5VXljA; timeZoneCode=190; .AspNet.ApplicationCookie=_dKZtM7IIskYWlZUbZjjrGanCHMwcTNBuP2JCTuiNFykrbh5eJReaJGmSkGyk4hVW4ssLqUr-XVa6CwRLi6pr_TRpYX-E51_9Cr2TA2zhhwZUv5Syu3pUNsP-6rQ4vzadkhfmWFuh0nf5F9zagtDo9ZZtZNCwHXwbYiiVa6U_C8MhY1YAU83Rn7fMYG8UQOYN_-kptwWEhjbhS1RYbv0k3VSV6xef-99SIr1OnlzjhBCkU6yIFkmlunt5x4i-c7el6ERAH4xni40mpLhKHgIIsPOXhXNvFngZ6k1nXmehonS92nXImzP7QsSGk0gJ2itHprxRKqF0wiLPZtmAdp1imHTdcjxjUdDQ0r1AZjkefeLw0eaVa7hg7omJpY4Z19tsQjQTuci0D4uUNLQ7UjEGoUr4xVtGxrscViq9UXw7xycBPmQbU6mHu70ntE4n3ghDeQrdrw3FLgIgllqFzPlTxZPu7CVLetDptZk8u2pRbzOZUkJIU-DBJ8VpkJx_BdjjGpZEHrhK7J2Jj72ySueMJtlU28qCpeChN4H7m-Eg8wPLRPSFSA7xO1jAbRHh9rPZOQSHil2HxxVTrPu-7zAI3DxlaUZfHUN89-DsrWOVjzKO7ucyUn1JJ6H9jlnwcIMvyoDe17uDUI0hksz_wGc1PSEaRn0srYRdbmwGX_yDp13u_opTTgKR8WScclS5p3WBK1zgmFBOHXG5x3JHMMNb3qHg_fTpwtrtYv9og8Eq-9gALDj-uXKcUYmBQGLC5nQxW4ZJmHQwuFr5i3MOANSujNwlLOXAVTLG0edMkJgDXyQwUWIbXofrCx4LBoR1w0nvOCe-ri1G-vK-liXBaKcA2vI8VjH5sgppBPW7tj4J6uZNQTTpASCgC8nIjUAAZ7hY0MZdxaAHn-1RDWf2YaQPYcBeMxXZ6t0xMZENarbxoM7S02HIKaFFe-Lwpm8-cYn6a-MTsmSK5WfvX4MLVYA9dOvSmEupHtnYbq2HD12FumJ-j9rgxTjy23mHtVMa43R57s8xsfaVxeUS8xraSVRpMoRb99ADxVjUmN3t1Mznj36Ihx15zUdnnfbDA_MOeBFcBrHCIZpkDzyMzbjd5xO9STiHWE7Dm4I-n8lUowXElQ2ZjMKyNQxlUx7uoJksSlkdW5rdcmO7Li0imwnsyvqX61fFfaJZ5YSJtS1uTm8kYO83Y1KS6KondhhDYk_yNR6bZwh0ATyBN8XHfxBDQd5Ch9kNCCK-XbvPgs5R9q7wcuxWCPIf72nnXdew6xU3xT__jAEHJli1CaJm5z989gFmeS29wDdB-V2PXuPaH2qhRUDvbUlU762zMmln5ujAX6D2oAnr0qnxRA0Cv3eodlBlEd6MqqOm2S1ICN_ctAHfbTm8lCBn4QtOnQfjudKTS2D1_xk_lLwaiPItIuHmIWzRXnAIihupU4_IbkqYU4LlCsBuFMrQzbCGzfEcFnhsG4ShrXTG_95eWIXUSi8meq6XLwvfwN8WZsB32SAMuFxxNTjr8IBa6tU1g5Vg8mrwT6UJ1enll6XcG5l1CcScCSVj0tB3P4Z89jUh7Qr9lmUaiRhuF1yUEYB3Y4DAD0T0KvzoSE500MLZs-jOuNcZbzxKGfsAXMdS0j7zexMeJUocrIdL28OSH69YCL1QbPU6GwmO7dT3oGs617zXLjSr4QbxRoc3pITFaQgkqeTgoKy1567SKE1RMFtbsHpXKpgNXPBXA59qErHq9w77yc360bnq283ocy_BWeZMIFT9szL3EhRq5knOGhoszBes7Zo_aaNQmI47tBny6i4jqyLrchp5RfS8Pjsx7P6tgktq2YvZkoUXON-PDnxl8McipCuJ2081kY5in_aIIF9JOsYB-hRAw2-Ph_ar-mypxfcqCZD-tKnQzjDvjEPpkjHfYfOHVHqecK__LABYF_djqkYpIeMQOvgkz-uWLNzl0xMUW0A9MnTXGvXYm0F_8hcYhpiKW2XKjTP6G0eHnal1KgCwV_wVS_mdSdsvpd8Lf55cpPf7dSGfo580U7NkUuWystwIFnwRRScZmGe0Jjs9mVieYCu5xs7En0OOX3TaAW_OuJqT0tjKXUSGwTVmuqgl0yrrnZtmOtoQKwFL2N_yo6jM_U4Qi2E1EGe84pUOxaXyi8dcxd5Q_4kcCQdI0cYbjr15kaiF_8NhDTKsHjdXp6Or4wAUu7d-PvOPCwcx155UefVLfov8DPcXX1v7KYxDZm1wt4yu5YzV-m9rotB0CmWMq7ZzTESVIHvpoRwxiCkJFAfPKjCqrSWnuWu0gSI75Wpz1nmf7OiX3hiFvhwYJya8wwA2TyKM1Ndel5PGlepIcFMtXX38iIeeWTsNaQqMI7_CxQSvXExSSnxdbRz0HcfEr33KCjrShKESJOezo0g7uJpgxk4uD-Hxxlpi6PRDSTbWJd8DmV7mIEyd7oNAIyY0cGNoB62wOmKyxb_LnX716G8OnO_T73cpL9RCko6Zc8ccogTVPfrlGizWsgps2gR1qqQ4FCYFSItxaiGUyivijRq7qL7M5BHFlUHwTqkIfdxneU2f5olWk2lgVfLJEqYJMhyAhuj80DdsqJ3B4E8o4Qhk4WP9KxyR-BJwVTsE_mHI34xiQvHKBN3Fhr4hs8LMAY_Qe2d8UiPW-_XT_7D2X-ApyGoYvBsHBijviQIoWpFAJ9re9umS6azyVVpiWTzMiAFlXsE_3ZKYvqT7gH6h3lzdsm_xFhQZyQy9EoTZ_-QFSTugr04uxARDV_8bWLXcdBgA88b2JOmqQWpYyEoFE70nVs5nlr-YmYIK7saupVwrI4ovm5bvt9oVdAvV0FLaJoAT0p7iafNT3MXLDE4iBTiEdx1Gnj_076UGDDlkbYTT9_Dy9qJPQRyNgq2WYlt50kbW_Zel7BHmtdN9c7IUC58dB0yygBBi_FklqT4tXK73yuwuRCaUqvXAUeumoic8HXLdRMtakmLoZN5YQc-J5Tm7ygD2QURXibEmW8txzHk_ya_cbs723AA_UzwofD3eDTSeuqhTr5orW1M_U1U5GvB6klRp14VlB092fPwbdeD17QZQhE2OzsHI7f2UP4-Cz-Rmw7iGJK1ebUMQPXDAsz8Wlg4eADt5XkC-vOkGRRcGKshL9hhVhGRY0RXAmduhLX1d6y51pxSKdDhE04EXBC0P47eGRdok9omY9TK5_eOxDJ_-4jf1DSjZtELLQWeaUVevorypVT8oLm7aYzjnPjY1OQAVDtk6U3FWrA3qdTiEJP6D9mXuDoiZUu5rqjMWFFZlriRIODyNR_HSk96yqU3zy9ZO65KvuIpt-GNWsFY53LFSN1WdUFI0pPdxOBwLwwy6IKWm3LFIN9XbFldRKJY9WyZLWOKTIi7rC0A5XD2D6H5KPHuVZahtzgsPeytNo9gHnauNLHGTy9997H2-hx0gTNtGepYFv50UIyyLGn47FtKgpGyRN1PNHWRa9FYwUvLmIs9jtalS3GHCpBCtiUgqhXopwSbeCvzpJoXLwnz0oRt8g10AoF_g6cEDEb5FZEcW8k7_qY0vaDBq8nf-t65FKSmPQrvqEWrGzbhkxQZwuqiI8_YwCDsXqJOWvt7RzS7oWNUWptRD3tUfIeVGX2daTkhH64PmcK9MqzdELJG4mRDRYQ9mk4mrxaaeJnetpXH6i4EQT8czBMHh6eUr4l_A1pSzNYLjoM8pF7oebJbWxyVJbSveKESyzCALDxR5S1ow49eantmQAabziuA9UI118GpUs-JK2YsrsiC3Apm824ecJLQoZYO99PXSVpGurPNwFN-x2lLl1lDpvRfXRuoOk8; ai_session=DJJYGtucqWcIrT8ffJGOf6|1719654628041|1719654724815' \
  -H 'origin: https://www.usvisascheduling.com' \
  -H 'priority: u=1, i' \
  -H 'referer: https://www.usvisascheduling.com/en-US/ofc-schedule/?reschedule=true' \
  -H 'request-id: |'$jj \
  -H 'sec-ch-ua: "Not/A)Brand";v="8", "Chromium";v="126", "Google Chrome";v="126"' \
  -H 'sec-ch-ua-mobile: ?0' \
  -H 'sec-ch-ua-platform: "Linux"' \
  -H 'sec-fetch-dest: empty' \
  -H 'sec-fetch-mode: cors' \
  -H 'sec-fetch-site: same-origin' \
  -H 'traceparent: 1'$jj \
  -H 'user-agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36' \
  -H 'x-requested-with: XMLHttpRequest' \
  --data-raw 'parameters={"primaryId":"8c1e756b-f0e5-ee11-a742-001dd80b1257","applications":["8c1e756b-f0e5-ee11-a742-001dd80b1257"],"scheduleDayId":"","scheduleEntryId":"","postId":"3f6bf614-b0db-ec11-a7b4-001dd80234f6","isReschedule":"true"}'|python3 -c"
import  json,sys;
import subprocess
from datetime import date, timedelta
result=json.load(sys.stdin)

#print(result['ScheduleDays']);
if(len(result['ScheduleDays'])>0):
    portalRange=[]
    for i in result['ScheduleDays']:
        #print(i['Date'][:-9])
        portalRange.append(i['Date'][:-9])

    #print('========================')
    def date_range_list(start_date, end_date):
        # Return generator for a list datetime.date objects (inclusive) between start_date and end_date (inclusive).
        curr_date = start_date
        while curr_date <= end_date:
            yield curr_date 
            curr_date += timedelta(days=1)

    start_date = date(year=2024, month=6, day=30)
    stop_date = date(year=2024, month=7, day=25)
    date_list = date_range_list(start_date, stop_date)
    userRange = []

    for date in date_list:
        userRange.append(str(date))
        #print(date)



    common = [a for a in portalRange if a in userRange]

    if(len(common)>0):
       
        for i in result['ScheduleDays']:
            if((i['Date'][:-9])==common[0]):
                print(i['ID']+';'+common[0])
   
    ")


echo available Date: $dayw

if [ "$dayw" != "" ];then
arrIN=(${dayw//;/ })
#echo $arrIN
dayId=${arrIN[0]}
echo ${arrIN[1]}
 timeId=$(curl_chrome110 -b cookie_j.txt -c cookie_j.txt 'https://www.usvisascheduling.com/en-US/custom-actions/?route=/api/v1/schedule-group/get-family-ofc-schedule-entries&cacheString='$jj \
  -H 'accept: application/json, text/javascript, */*; q=0.01' \
  -H 'accept-language: en-US,en;q=0.9' \
  -H 'content-type: application/x-www-form-urlencoded; charset=UTF-8' \
  -H 'cookie: ai_user=bW7XPWHbxqUoKtw4KYB9ZC|2024-06-27T12:44:07.129Z; Dynamics365PortalAnalytics=K1B_uMKhbzrM60Ir7RO5uC0U2KbRacP7EM6tZpRaqi_J1F93o46GY2CCZ0_oJmhGvIZokrO4rMUu7OhsNLnQPaU01dwKbZDLUY21M7RCSds7QWQwo9d2SZiQGPK7dsAD4QicNaJe9VHZwr1lDb-rFA2; ASP.NET_SessionId=wm3bvgquba2y5bu0siwrklew; ARRAffinity=3bf8829b4314cc88291bac4130bb39f2498ea1af76e709ccc5192f2a63139759; ARRAffinitySameSite=3bf8829b4314cc88291bac4130bb39f2498ea1af76e709ccc5192f2a63139759; __cf_bm=Ix69pf34sKixviuSh0w64DBnpG5kegC5IaV02eN0jhw-1719654627-1.0.1.1-iBOQom.GlMXt0uzomg06CeL6bnOiTlZ3i99L3NaoOf5a6jyKdTv4eAzRp_7j3lRonFTtcdg_VUfCCBuSBPdTFg; timezoneoffset=-330; isDSTSupport=false; isDSTObserved=false; ContextLanguageCode=en-US; cf_clearance=ilz3r1TtxCiRZd5Zo_4ZgGJ6XP0e1bpF79E9MN.WUrc-1719654660-1.0.1.1-w.lIap.jnjrTyN0ErCrIxoM_MlHMt_PYMOu6VT5hG_16SZO0OJ8syXF7kIeWuAHWZJs6i2LLyfXNi4Ry5VXljA; timeZoneCode=190; .AspNet.ApplicationCookie=_dKZtM7IIskYWlZUbZjjrGanCHMwcTNBuP2JCTuiNFykrbh5eJReaJGmSkGyk4hVW4ssLqUr-XVa6CwRLi6pr_TRpYX-E51_9Cr2TA2zhhwZUv5Syu3pUNsP-6rQ4vzadkhfmWFuh0nf5F9zagtDo9ZZtZNCwHXwbYiiVa6U_C8MhY1YAU83Rn7fMYG8UQOYN_-kptwWEhjbhS1RYbv0k3VSV6xef-99SIr1OnlzjhBCkU6yIFkmlunt5x4i-c7el6ERAH4xni40mpLhKHgIIsPOXhXNvFngZ6k1nXmehonS92nXImzP7QsSGk0gJ2itHprxRKqF0wiLPZtmAdp1imHTdcjxjUdDQ0r1AZjkefeLw0eaVa7hg7omJpY4Z19tsQjQTuci0D4uUNLQ7UjEGoUr4xVtGxrscViq9UXw7xycBPmQbU6mHu70ntE4n3ghDeQrdrw3FLgIgllqFzPlTxZPu7CVLetDptZk8u2pRbzOZUkJIU-DBJ8VpkJx_BdjjGpZEHrhK7J2Jj72ySueMJtlU28qCpeChN4H7m-Eg8wPLRPSFSA7xO1jAbRHh9rPZOQSHil2HxxVTrPu-7zAI3DxlaUZfHUN89-DsrWOVjzKO7ucyUn1JJ6H9jlnwcIMvyoDe17uDUI0hksz_wGc1PSEaRn0srYRdbmwGX_yDp13u_opTTgKR8WScclS5p3WBK1zgmFBOHXG5x3JHMMNb3qHg_fTpwtrtYv9og8Eq-9gALDj-uXKcUYmBQGLC5nQxW4ZJmHQwuFr5i3MOANSujNwlLOXAVTLG0edMkJgDXyQwUWIbXofrCx4LBoR1w0nvOCe-ri1G-vK-liXBaKcA2vI8VjH5sgppBPW7tj4J6uZNQTTpASCgC8nIjUAAZ7hY0MZdxaAHn-1RDWf2YaQPYcBeMxXZ6t0xMZENarbxoM7S02HIKaFFe-Lwpm8-cYn6a-MTsmSK5WfvX4MLVYA9dOvSmEupHtnYbq2HD12FumJ-j9rgxTjy23mHtVMa43R57s8xsfaVxeUS8xraSVRpMoRb99ADxVjUmN3t1Mznj36Ihx15zUdnnfbDA_MOeBFcBrHCIZpkDzyMzbjd5xO9STiHWE7Dm4I-n8lUowXElQ2ZjMKyNQxlUx7uoJksSlkdW5rdcmO7Li0imwnsyvqX61fFfaJZ5YSJtS1uTm8kYO83Y1KS6KondhhDYk_yNR6bZwh0ATyBN8XHfxBDQd5Ch9kNCCK-XbvPgs5R9q7wcuxWCPIf72nnXdew6xU3xT__jAEHJli1CaJm5z989gFmeS29wDdB-V2PXuPaH2qhRUDvbUlU762zMmln5ujAX6D2oAnr0qnxRA0Cv3eodlBlEd6MqqOm2S1ICN_ctAHfbTm8lCBn4QtOnQfjudKTS2D1_xk_lLwaiPItIuHmIWzRXnAIihupU4_IbkqYU4LlCsBuFMrQzbCGzfEcFnhsG4ShrXTG_95eWIXUSi8meq6XLwvfwN8WZsB32SAMuFxxNTjr8IBa6tU1g5Vg8mrwT6UJ1enll6XcG5l1CcScCSVj0tB3P4Z89jUh7Qr9lmUaiRhuF1yUEYB3Y4DAD0T0KvzoSE500MLZs-jOuNcZbzxKGfsAXMdS0j7zexMeJUocrIdL28OSH69YCL1QbPU6GwmO7dT3oGs617zXLjSr4QbxRoc3pITFaQgkqeTgoKy1567SKE1RMFtbsHpXKpgNXPBXA59qErHq9w77yc360bnq283ocy_BWeZMIFT9szL3EhRq5knOGhoszBes7Zo_aaNQmI47tBny6i4jqyLrchp5RfS8Pjsx7P6tgktq2YvZkoUXON-PDnxl8McipCuJ2081kY5in_aIIF9JOsYB-hRAw2-Ph_ar-mypxfcqCZD-tKnQzjDvjEPpkjHfYfOHVHqecK__LABYF_djqkYpIeMQOvgkz-uWLNzl0xMUW0A9MnTXGvXYm0F_8hcYhpiKW2XKjTP6G0eHnal1KgCwV_wVS_mdSdsvpd8Lf55cpPf7dSGfo580U7NkUuWystwIFnwRRScZmGe0Jjs9mVieYCu5xs7En0OOX3TaAW_OuJqT0tjKXUSGwTVmuqgl0yrrnZtmOtoQKwFL2N_yo6jM_U4Qi2E1EGe84pUOxaXyi8dcxd5Q_4kcCQdI0cYbjr15kaiF_8NhDTKsHjdXp6Or4wAUu7d-PvOPCwcx155UefVLfov8DPcXX1v7KYxDZm1wt4yu5YzV-m9rotB0CmWMq7ZzTESVIHvpoRwxiCkJFAfPKjCqrSWnuWu0gSI75Wpz1nmf7OiX3hiFvhwYJya8wwA2TyKM1Ndel5PGlepIcFMtXX38iIeeWTsNaQqMI7_CxQSvXExSSnxdbRz0HcfEr33KCjrShKESJOezo0g7uJpgxk4uD-Hxxlpi6PRDSTbWJd8DmV7mIEyd7oNAIyY0cGNoB62wOmKyxb_LnX716G8OnO_T73cpL9RCko6Zc8ccogTVPfrlGizWsgps2gR1qqQ4FCYFSItxaiGUyivijRq7qL7M5BHFlUHwTqkIfdxneU2f5olWk2lgVfLJEqYJMhyAhuj80DdsqJ3B4E8o4Qhk4WP9KxyR-BJwVTsE_mHI34xiQvHKBN3Fhr4hs8LMAY_Qe2d8UiPW-_XT_7D2X-ApyGoYvBsHBijviQIoWpFAJ9re9umS6azyVVpiWTzMiAFlXsE_3ZKYvqT7gH6h3lzdsm_xFhQZyQy9EoTZ_-QFSTugr04uxARDV_8bWLXcdBgA88b2JOmqQWpYyEoFE70nVs5nlr-YmYIK7saupVwrI4ovm5bvt9oVdAvV0FLaJoAT0p7iafNT3MXLDE4iBTiEdx1Gnj_076UGDDlkbYTT9_Dy9qJPQRyNgq2WYlt50kbW_Zel7BHmtdN9c7IUC58dB0yygBBi_FklqT4tXK73yuwuRCaUqvXAUeumoic8HXLdRMtakmLoZN5YQc-J5Tm7ygD2QURXibEmW8txzHk_ya_cbs723AA_UzwofD3eDTSeuqhTr5orW1M_U1U5GvB6klRp14VlB092fPwbdeD17QZQhE2OzsHI7f2UP4-Cz-Rmw7iGJK1ebUMQPXDAsz8Wlg4eADt5XkC-vOkGRRcGKshL9hhVhGRY0RXAmduhLX1d6y51pxSKdDhE04EXBC0P47eGRdok9omY9TK5_eOxDJ_-4jf1DSjZtELLQWeaUVevorypVT8oLm7aYzjnPjY1OQAVDtk6U3FWrA3qdTiEJP6D9mXuDoiZUu5rqjMWFFZlriRIODyNR_HSk96yqU3zy9ZO65KvuIpt-GNWsFY53LFSN1WdUFI0pPdxOBwLwwy6IKWm3LFIN9XbFldRKJY9WyZLWOKTIi7rC0A5XD2D6H5KPHuVZahtzgsPeytNo9gHnauNLHGTy9997H2-hx0gTNtGepYFv50UIyyLGn47FtKgpGyRN1PNHWRa9FYwUvLmIs9jtalS3GHCpBCtiUgqhXopwSbeCvzpJoXLwnz0oRt8g10AoF_g6cEDEb5FZEcW8k7_qY0vaDBq8nf-t65FKSmPQrvqEWrGzbhkxQZwuqiI8_YwCDsXqJOWvt7RzS7oWNUWptRD3tUfIeVGX2daTkhH64PmcK9MqzdELJG4mRDRYQ9mk4mrxaaeJnetpXH6i4EQT8czBMHh6eUr4l_A1pSzNYLjoM8pF7oebJbWxyVJbSveKESyzCALDxR5S1ow49eantmQAabziuA9UI118GpUs-JK2YsrsiC3Apm824ecJLQoZYO99PXSVpGurPNwFN-x2lLl1lDpvRfXRuoOk8; ai_session=DJJYGtucqWcIrT8ffJGOf6|1719654628041|1719654724815' \
  -H 'origin: https://www.usvisascheduling.com' \
  -H 'priority: u=1, i' \
  -H 'referer: https://www.usvisascheduling.com/en-US/ofc-schedule/?reschedule=true' \
  -H 'request-id: |'$jj \
  -H 'sec-ch-ua: "Not/A)Brand";v="8", "Chromium";v="126", "Google Chrome";v="126"' \
  -H 'sec-ch-ua-mobile: ?0' \
  -H 'sec-ch-ua-platform: "Linux"' \
  -H 'sec-fetch-dest: empty' \
  -H 'sec-fetch-mode: cors' \
  -H 'sec-fetch-site: same-origin' \
  -H 'traceparent: 1'$jj \
  -H 'user-agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36' \
  -H 'x-requested-with: XMLHttpRequest' \
  --data-raw 'parameters={"primaryId":"8c1e756b-f0e5-ee11-a742-001dd80b1257","applications":["8c1e756b-f0e5-ee11-a742-001dd80b1257"],"scheduleDayId":"'"$dayId"'","scheduleEntryId":"","postId":"3f6bf614-b0db-ec11-a7b4-001dd80234f6"}'|python3 -c"
import  json,sys;
import subprocess
from datetime import date, timedelta
result1=json.load(sys.stdin)

print(result1['ScheduleEntries'][0]['ID']);"
 )
echo $timeId   
else
    echo 'Date range/ofc dates is not available :'$(date +%H-%M-%S)
fi
 done

