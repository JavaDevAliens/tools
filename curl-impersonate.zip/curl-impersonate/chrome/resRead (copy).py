import  json,sys;
import subprocess
from datetime import date, timedelta
result=json.load(sys.stdin)

#print(result['ScheduleDays']);
portalRange=[]
for i in result['ScheduleDays']:
    #print(i['Date'][:-9])
    portalRange.append(i['Date'][:-9])


def date_range_list(start_date, end_date):
    # Return generator for a list datetime.date objects (inclusive) between start_date and end_date (inclusive).
    curr_date = start_date
    while curr_date <= end_date:
        yield curr_date 
        curr_date += timedelta(days=1)

start_date = date(year=2025, month=2, day=16)
stop_date = date(year=2025, month=11, day=25)
date_list = date_range_list(start_date, stop_date)
userRange = []

for date in date_list:
    userRange.append(str(date))
    #print(date)


njj='dfdf'
common = [a for a in portalRange if a in userRange]

if(len(common)>0):
   
    for i in result['ScheduleDays']:
        if((i['Date'][:-9])==common[0]):
            print(common[0])

print('662764732647346')
