import sys;


print('jjj')
print(sys.argv[1])

print(sys.argv[2])
print(sys.argv[3])
print(sys.argv[4])
print(sys.argv[5])
print(sys.argv[6])
print(sys.argv[1])
