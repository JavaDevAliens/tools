jj=$(shuf -i 999999999999999999-9999999999999999999 -n 1)
echo $jj



curl_chrome110 -b cookie_j.txt -c cookie_j.txt 'https://www.usvisascheduling.com/en-US/custom-actions/?route=/api/v1/schedule-group/get-family-ofc-schedule-days&cacheString='$jj \
  -H 'accept: application/json, text/javascript, */*; q=0.01' \
  -H 'accept-language: en-US,en;q=0.9' \
  -H 'content-type: application/x-www-form-urlencoded; charset=UTF-8' \
  -H 'cookie: ASP.NET_SessionId=aewxdrdlgz1dg1eexiqtf44c; timezoneoffset=-330; isDSTSupport=false; isDSTObserved=false; ContextLanguageCode=en-US; ai_user=bW7XPWHbxqUoKtw4KYB9ZC|2024-06-27T12:44:07.129Z; timeZoneCode=190; Dynamics365PortalAnalytics=K1B_uMKhbzrM60Ir7RO5uC0U2KbRacP7EM6tZpRaqi_J1F93o46GY2CCZ0_oJmhGvIZokrO4rMUu7OhsNLnQPaU01dwKbZDLUY21M7RCSds7QWQwo9d2SZiQGPK7dsAD4QicNaJe9VHZwr1lDb-rFA2; ARRAffinity=373b9b5f484f54ac4ee9855156cdcae474be573baafe1b9612b052c9bdded452; ARRAffinitySameSite=373b9b5f484f54ac4ee9855156cdcae474be573baafe1b9612b052c9bdded452; cf_clearance=8knKkefEghcoEIBYnZTJe12876Y2fvFbDi1xJ3G3.Mg-1719509170-1.0.1.1-VlOKhTJj.fePMma_z_8wAjzNorILlnsFc_QDyf3xExA3HU0s6ewCZNCwp_BZ.Co.2.4ie9xcqFv1agWzFbnA9A; __cf_bm=gczflV3.GQ88FRabmEygcobcaYq7pkglEzp76owenIg-1719511822-1.0.1.1-x6l2tBP6MC_zZGRFuuaXjE5GqhDhWRt4cUCcko8xYj2V5xQudz_xjoljb75k10cLer8qBpBdLakaNk737RzU7w; .AspNet.ApplicationCookie=uyrDVZ4LA6Lfgsk-bHW-NCT604zZ-HecF-Q-4rh4eT4DWuaQqErH81yg6suU2OXhXkCK-jXsbERKY_Tv9mfjcD1QmJhzsY3_AcLqMh1q50JFCXitseiwDgZVRRDwWQ2N7b-sbXFkJTEfUruqXNEor7KFieZU7KC1nT0xe_idVj-EhZT8DoetbHZYIb1jvBK-0iBm5jyJoHD3tjDBmEDirSwIFl32pFuEbqhmlKc-xMXwgDD2PHVxHsT6wGbEUaS43V8X314E7wY1nCCyMxKj6R5jVmmOcewXTdUAySYkwclRC0ElHu37cxx68rzOM828r_XaDv4B7PAIzuQxGlCBnRFqOzB9NDz3segvcj5P-T3HReQaLcEEoosOWQSOuB8Zq9zpw7OW7n0giFeCrczX2SkXRvLt6rPZ7dNFXvTQ_y_w5y9s81edg47NrUadPhuUNURfPFjeBRBi3X77Ma4ifeuTHvvvKGoj5GGVqoJhdgEMqkNyZnoeB7ln2cFoUARiAK9rFoqVytvqccaa0J6P-bTBlZsgSbvWZmsfQb2oEWm5KdTWRUU9r_b391dgiQmm0zGJAjknq-raF5uPCNrqnJMiCuCeBG_eLB45mi-E_6KAW8rI2Cgb_CumwqlESoS2D--qjgY-TR4qTTKSNFm2GRcWYtsSzxW3UtB_MFSKIh4o1y4xckdB1Zz9lx9rCUo93K6Al1nHk6wR0j5I1oMzsT2M964H3QjnM26SU41aqBc7JCFT3aUEX2tw1E0MnS4fus5El0Oira2kKPKoP__qdPUbknkhhoEFlZm0rczQswwjna9d53i3BOt__3Cnap3baM3e4ZQ6va9YXHfsrqhLX7e-48YelJY5GU7mknT-1JtpNCwmug6rf3nLlIwCDLY4nVtRNbC4ucze4ZUbMBuTjiHT1AihXKDcUgEVjhtzDOvtfW1mWpsqFmygiUr4nOlfzypkP3LbU6q6G-3AMPNCSvgS11mKf9ezYMJ6HlC8xAab2t492eTItwZ2sH0bcyJBK_TJrtKI-prKqJerJ7GcqSXu2eE5JtTJM1A34O4awF3mNM0Faey1vOXl9GG5pG6ECy6zj2wBXe-Rdi3n2ejOQzNxGRF5myXhk_nsDRcic21Fl5cU0yltohextTrOojlsa_VzIUpxKn-GanqODNWtWiARh2B8wNKX7qUfg1PnIqJveXXyHvJFW7LTUWeC359dJhyi_gZLutuq2PuXw5DSV13IItI_M8NKq4D6Qh-E0RngM6q6bGfuDH0Xojwu4lc5Jbm7wCEygNi80HKw1aKh_VWYAngUCdaM4z6EfSr3yvuIsGHwQARnae9lM_weF-mvZcn1bse2IO1n_z7Vk43FugPAfVV3jJN5B38KvjpHVD-bAqHc_kTS1HS6Y4dGIAbElHPBOKRKzt7EgM8_7CzZw5SFhE4CFv9bzUAufRwj9XKMVQVmJMn2Gcd8uIZxUir5esJjM4h0Zr5e0qvT9e7ddpFcnqoY3q6uOT8AM0V23uy-PsJkTmYWCPMkbyMPBPqOxQ8uuRARoEjQh6O-nFnh2Nyl-LbyxJ9ZbUIDXr1J1Poz9678iuUBOjGF9U-bl2T9_VLxvZohcPRN3lmfpCcnAzFV58s73J4rlzkCXcvJC1m3Iok5LzHErOvHOEz6FQ8WnCZjvBM1XnxM53bM4lfdu-wf1xBEQi2Kd4Qvq2m40qzqhOwcjl4S4xUkFC-5XypucNrK9YwQPPjfqmCLaPNrfOiJdpfjeJGKEHG86ZWDImEu_Mq6E_7VGp8CpFyMhIKZgsEh8HoxfsNmjd7YZk_xZfI7dWjyg3pwNTdIGjGMHFtqf9USjoGlATcthhaQUFbFc5526Ex-oGMN_ubM0z2z-eRtUC0ts8-5J3GYFCtmZhsxiURm7ldKr5XbIDEfR33BQkwPoB0VvPOMkZTVEpDMB__Q94ICIbdEaqN9Y3V9ahxk70TdW7HZX7dUjOU7a4hghHeYQMglJ3hgWftocFV7ZonILzQh5_6b0mW_gidmYQ3EWhX-oOuPk7nU93zt9ubrppzT1zbWoY8URPFyydQ7MsEuQaf992CUii96qg44XiU2645OEzh2liyc4DJe6Tlb3yduD-C4f9EBGyP43ACUV5SihQx5NBUeJJi0y4eNL87BA7QBh27HgcjSSDgIs1bwP58vfZ929b5RF88tyvJcMKhlv-DxQWnwFH4Oej2XdNZPTtVymjyyUM9kfvQp0rKB4phGS82xE9PWkqeZxM8L0yy9ex7bEUSp6bhOKDV650Fhng5Vmba8TtnMiWqyMc1QxwFNJYwo9NA43YnQ81ZNFepqoHEXCDqsF9JfeJ_FBQwA7Kusw0UdaTunT5EfkRTh7EgfSZheu3Nbcn2A99c1UeJ8QbZC9qE-o3konMosu5ajdOJcetQpZb1QAxg2fhwjLWVHMPqTrpdIiBMCnSp8e0-WI_GVrGMQpD0RKhJxKsNYZSef3OJvDkS-4Kc7fUZLj8bWIdIzF0fjHKYh8d5Dau5O0iu00m2P0zOcNrQIGn92GGsj4i2yzMCUcZ3L-bfcFO2HaMOlF9uhpb5F4Tot7shaF0KvGUHUQ7QvLThM9dGaq93Tq79r_3x3HRPxqq5BiYHSUxU64Rd4q_2vQ7Nn5D3CUv_ShZt5Pw-D3K-TE2218dutg8RNjeaqzeQSqfBW7lQo2yOo6YTurveQ2HfkNuCJcbCQeWxbJofNU_BacuNdNHFEg75ScCtb-0W7nkxGDxnAZYEbFTdG0PGkLBohpZF5LfG6j8SjCl9JT86BeTiFUqNsobioCIbgJJz-IlhgpHR4kAg2Dv9NjvrJOfX6KmBgdgCxBAWcDYB9ykitX4tvSjvmi1b87qDF25VKVXqmZk8uUv7abDvoIqa5nE7u9sR6jAIg44KIccDHR1TkgaaT5GMeZDXYvU2M5IuME6djTQNhdwMoz3Ta_8GoIdTvMQoc2CLTpHNybP-bJs21seYPsR0IbR8xnD-vKQxhCWu243yBU3HLkY59E8MSRWgapoVf-mHI-OFTikwy7G7VvMHkPvmtPkYOXaJk8lSIh1tiJA0oMUeNGvxmZyft6NDXMCD_hnz2fPtesPPfb5hf0WWIgQh7R2Db3AYPJcrpH-O3sUFkUPhXHEsuDz_JG17GXPrm-iL28pPXsV29j7SRcAf1fn0rkHdWb76GT_W9JqOOSxECTQddU34h1ogJbEkhDUNw6dQDLQA-sm1AlbgdQrOl7lkOv9ts4vdY1M6HI6z_JDvsWGnW4bfJh1Ikve50Gev4Mu4GgV5Dqrq2kdJKNhr3Gtr9j7HEaqWpLQUFp87FJ6wfO_Zkjxp7IyktFwOaX1U426VieeCFyMgeSza0EcJtY_TpxNxGM3_oQ5RMtveyMvUqLYIwdFRSk9iltoIzPC6sgjTjSoWxaGHR20B-bBq59PtC_ysl5il11YXGa7Rgct_KFPDD2ex8yTz-1nOg1_c3CDHRvYUu3e4tfwnNMFWrDPY1iSOkJ9qNQyj6iZ6w4sDNbjVqp8JS3bFo6Ef2DjpXqSEetKQogEZUgEtdzJNGIo5BAUD6Kv97lj4lBeJyfUiVPIt4F_fF2CI_CNZJebuMD8cOf_O4g2JYzSa-sf736iepjQRVAWeW9ugNzLmQoQncZCMl-XbIijCGKnlfOVqCL1kqPpPT-2Jihw1C_mdPbpjgbpzqCf50IG0Jmvfahgsvun7Ome9eCi56HS7EHrDTBKJmvWeuTSYI3cKrwz8EVfUJ5MqMzQgqLC09U_ltrIAvGEngeA-1pPZeBIQmBQ' \
  -H 'origin: https://www.usvisascheduling.com' \
  -H 'priority: u=1, i' \
  -H 'referer: https://www.usvisascheduling.com/en-US/ofc-schedule/' \
  -H 'request-id: |'$jj$jj \
  -H 'sec-ch-ua: "Not/A)Brand";v="8", "Chromium";v="126", "Google Chrome";v="126"' \
  -H 'sec-ch-ua-arch: "x86"' \
  -H 'sec-ch-ua-bitness: "64"' \
  -H 'sec-ch-ua-full-version: "126.0.6478.114"' \
  -H 'sec-ch-ua-full-version-list: "Not/A)Brand";v="8.0.0.0", "Chromium";v="126.0.6478.114", "Google Chrome";v="126.0.6478.114"' \
  -H 'sec-ch-ua-mobile: ?0' \
  -H 'sec-ch-ua-model: ""' \
  -H 'sec-ch-ua-platform: "Linux"' \
  -H 'sec-ch-ua-platform-version: "5.15.0"' \
  -H 'sec-fetch-dest: empty' \
  -H 'sec-fetch-mode: cors' \
  -H 'sec-fetch-site: same-origin' \
  -H 'traceparent: 00-'$jj \
  -H 'user-agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36' \
  -H 'x-requested-with: XMLHttpRequest' \
  --data-raw 'parameters={"primaryId":"978b2d40-b427-ef11-a296-001dd8087c53","applications":["978b2d40-b427-ef11-a296-001dd8087c53"],"scheduleDayId":"","scheduleEntryId":"","postId":"436bf614-b0db-ec11-a7b4-001dd80234f6","isReschedule":"false"}'| 
python3 -c"
import  json,sys;
import subprocess
from datetime import date, timedelta
result=json.load(sys.stdin)

#print(result['ScheduleDays']);
portalRange=[]
for i in result['ScheduleDays']:
    #print(i['Date'][:-9])
    portalRange.append(i['Date'][:-9])

print('========================')
def date_range_list(start_date, end_date):
    # Return generator for a list datetime.date objects (inclusive) between start_date and end_date (inclusive).
    curr_date = start_date
    while curr_date <= end_date:
        yield curr_date 
        curr_date += timedelta(days=1)

start_date = date(year=2025, month=2, day=16)
stop_date = date(year=2025, month=11, day=25)
date_list = date_range_list(start_date, stop_date)
userRange = []

for date in date_list:
    userRange.append(str(date))
    #print(date)



common = [a for a in portalRange if a in userRange]

if(len(common)>0):
   
    for i in result['ScheduleDays']:
        if((i['Date'][:-9])==common[0]):
            print(common[0])



"


