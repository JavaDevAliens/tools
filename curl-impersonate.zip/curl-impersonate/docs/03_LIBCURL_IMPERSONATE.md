# Using libcurl-impersonate

Documentation for using libcurl-impersonate is currently on the [main page](https://github.com/lwthiker/curl-impersonate#libcurl-impersonate)
