# Using libcurl-impersonate in JS scripts

It is possible to make the `node-libcurl` package work with libcurl-impersonate instead of libcurl. Instructions are currently available in [Issue #80](https://github.com/lwthiker/curl-impersonate/issues/80).
